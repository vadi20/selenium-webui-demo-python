class Config:
    BASE_URL = "https://www.demoblaze.com/"
    BROWSER = "chrome"  # "firefox", "edge", "safari"
    IMPLICIT_WAIT = 10
    EXPLICIT_WAIT = 20
    HEADLESS = False
    USERNAME = "demotest006"
    PASSWORD = "demotest006"